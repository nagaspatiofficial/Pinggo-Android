# Build PINGGO AAB dari iPhone via GitHub Actions

Project ini membangun **signed Android App Bundle (.aab)** di GitHub Actions tanpa Android Studio.

## 1. Buat repository Android terpisah
Jangan campur dengan repository web `Pinggo` yang menayangkan PWA.
Buat repository baru, contoh: `Pinggo-Android`.

Upload seluruh isi folder project ini ke root repository baru, termasuk folder `.github`.

## 2. Masukkan 4 GitHub Actions Secrets
Buka repository > Settings > Secrets and variables > Actions > New repository secret.

Tambahkan:
- `PINGGO_KEYSTORE_BASE64`
- `PINGGO_STORE_PASSWORD`
- `PINGGO_KEY_ALIAS`
- `PINGGO_KEY_PASSWORD`

Nilainya ada di file rahasia terpisah yang diberikan bersama paket ini. Jangan commit file rahasia atau `.jks` ke repository.

## 3. Jalankan build
Buka tab **Actions** > **Build PINGGO Android AAB** > **Run workflow**.

Jika sukses, pada bagian **Artifacts** akan muncul:
`PINGGO-PlayStore-AAB`

Download artifact tersebut. Di dalamnya ada `app-release.aab` untuk Play Console.

## 4. Jangan hapus upload key
Simpan file `pinggo-upload.jks` dan data rahasianya di tempat aman. Key yang sama diperlukan untuk update berikutnya.
