# PINGGO Android / Google Play

Project Android wrapper untuk PINGGO menggunakan Trusted Web Activity (TWA).

- App name: PINGGO
- Package: app.pinggo.mobile
- Web app: https://nagaspatiofficial.github.io/Pinggo/
- minSdk: 24
- targetSdk: 36
- version: 1.0.0 (1)

## Yang sudah disiapkan

- AndroidManifest dengan launcher TWA
- Deep link ke `/Pinggo/`
- Warna PINGGO
- Ikon launcher sementara diambil dari ikon PINGGO pada screenshot pengguna
- Konfigurasi Android Browser Helper
- Template Digital Asset Links
- Konfigurasi Gradle untuk Android Studio

## Penting sebelum upload ke Play Store

TWA harus diverifikasi dengan Digital Asset Links. Karena website PINGGO berada di:

https://nagaspatiofficial.github.io/Pinggo/

maka file assetlinks harus tersedia pada ROOT origin:

https://nagaspatiofficial.github.io/.well-known/assetlinks.json

BUKAN di `/Pinggo/.well-known/assetlinks.json`.

Isi template tersedia di `web-root/.well-known/assetlinks.json.template`. Setelah upload key dibuat, ganti placeholder fingerprint SHA-256 dengan fingerprint signing certificate yang benar.

Jika root `nagaspatiofficial.github.io` belum bisa kamu kontrol, ada dua pilihan:
1. buat GitHub Pages root site untuk akun tersebut, atau
2. pindahkan PINGGO ke custom domain milik sendiri (lebih disarankan untuk rilis jangka panjang).

Tanpa Digital Asset Links yang valid, aplikasi masih dapat membuka situs melalui Custom Tab, tetapi tidak akan mendapatkan pengalaman TWA terverifikasi sepenuhnya.

## Cara build di Android Studio

1. Install Android Studio terbaru + JDK 17.
2. Open folder project ini.
3. Install Android SDK Platform 36 jika diminta.
4. Sync Gradle.
5. Test: Run ke Android phone/emulator.
6. Release: Build > Generate Signed App Bundle / APK > Android App Bundle.
7. Buat/upload keystore yang kamu simpan permanen.
8. Ambil SHA-256 signing certificate dari keystore/Play App Signing, lalu update `assetlinks.json`.
9. Upload `assetlinks.json` ke root origin website.
10. Upload file `.aab` ke Google Play Console.

## Catatan keamanan

Jangan kehilangan upload keystore. Jangan upload file keystore atau password ke repository publik.
