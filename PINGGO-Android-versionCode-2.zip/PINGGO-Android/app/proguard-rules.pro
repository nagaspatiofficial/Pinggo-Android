# PINGGO currently does not enable code shrinking.
