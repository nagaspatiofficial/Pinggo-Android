# PINGGO Android / Google Play

Proyek Android ini membungkus PINGGO sebagai aplikasi Android dengan package ID
`com.pinggo.app`. Konten web disimpan di dalam aplikasi, sedangkan
login, chat, media, dan data tetap memakai backend Supabase yang sudah digunakan.

## Membuat file AAB

1. Upload seluruh isi folder ini ke repository GitHub baru/private.
2. Buka tab **Actions** → **Build PINGGO AAB** → **Run workflow**.
3. Setelah selesai, unduh artifact `PINGGO-com.pinggo.app-release-aab`.
4. Di dalam artifact terdapat `PINGGO-com.pinggo.app-release.aab` yang sudah
   ditandatangani dan bisa langsung di-upload ke Google Play Console.

Jangan kehilangan file upload key dan kata sandinya. Semua update PINGGO berikutnya
harus ditandatangani dengan upload key yang sama.

## Data Google Play

- App name: PINGGO
- Package name: `com.pinggo.app`
- Version: 1.0.1 (versionCode 2)
- Minimum Android: Android 6.0 (API 23)
- Target Android: API 35
- Permissions: Internet, Camera, Microphone, Notifications

**Penting:** repository GitHub harus PRIVATE karena proyek berisi upload key.
Simpan ZIP asli sebagai cadangan. Jangan menghapus `pinggo-upload-key.jks` atau
mengubah `keystore.properties`, karena update berikutnya harus memakai key yang sama.

Sebelum production, siapkan privacy policy, fitur report/block/moderation untuk
konten pengguna, account deletion, Data safety form, content rating, dan gunakan
Google Play Billing jika PINGGO Coin dijual sebagai barang digital dalam aplikasi.
